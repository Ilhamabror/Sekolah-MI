<?php


class Kelurahan_model extends CI_model{

	function get_datakelurahan()
	{
		$query= $this->db->get('kelurahan');
		return $query->result_array();
	}
		function prosesAddData(){
		$id_kelurahan= $this->input->post('id_kel');
		$nama_kelurahan= $this->input->post('nama_kel');
		$id_kecamatan= $this->input->post('id_kec');
               //Mmebuat array data untuk dimasukkan ke tabel kelurahan
		$data = array(
			'id_kel' => $id_kelurahan,
			'nama_kel' => $nama_kelurahan,
			'id_kec' => $id_kecamatan,
		);

		// menimpan data ke tabel kelurahan
		$this ->db->insert('kelurahan',$data);
		$this->session->set_flashdata('notif', 'Data Kelurahan Berhasil Ditambahakan');
		redirect(base_url('admin/Kelurahan'));


	} 

	function hapusData($id_kel){
		$this->db->where('id_kel',$id_kel);
		$this->db->delete('kelurahan');
		$this->session->set_flashdata('notif', 'Data kelurahan berhasil dihapus');
		redirect(base_url('admin/Kelurahan'));

	}
	function ProsesUpdateData(){
		$id_kelurahan= $this->input->post('id_kel');
		$nama_kelurahan= $this->input->post('nama_kel');
		$id_kecamatan= $this->input->post('id_kec');
	
			$data= array('id_kel' => $id_kelurahan ,
						'nama_kel' =>$nama_kelurahan ,
						'id_kec' =>$id_kecamatan);
			$this->db->where('id_kel',$id_kelurahan);
			$this->db->update('kelurahan',$data);
			redirect('admin/Kelurahan');
	}

}

   
?>