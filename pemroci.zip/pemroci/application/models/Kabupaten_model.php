<?php


class Kabupaten_model extends CI_model{

	function get_datakabupaten()
	{
		$query= $this->db->get('kabupaten');
		return $query->result_array();
	}
		function prosesAddData(){
		$id_kabupaten= $this->input->post('id_kab');
		$nama_kabupaten= $this->input->post('nama_kab');
		
               //Membuat array data untuk dimasukkan ke tabel kabupaten
		$data = array(
			'id_kab' => $id_kabupaten,
			'nama_kab' => $nama_kabupaten,
			
		);

		// menyimpan data ke tabel kabupaten
		$this ->db->insert('kabupaten',$data);
		$this->session->set_flashdata('notif', 'Data Kabupaten Berhasil Ditambahakan');
		redirect(base_url('admin/Kabupaten'));


	} 

	function hapusData($id_kab){
		$this->db->where('id_kab',$id_kab);
		$this->db->delete('kabupaten');
		$this->session->set_flashdata('notif', 'Data Kabupaten berhasil dihapus');
		redirect(base_url('admin/Kabupaten'));

	}
	function ProsesUpdateData(){
		$id_kabupaten= $this->input->post('id_kab');
		$nama_kabupaten= $this->input->post('nama_kab');
		
			$data= array('id_kab' => $id_kabupaten ,
						'nama_kab' =>$nama_kabupaten ,
						);
			$this->db->where('id_kab',$id_kabupaten);
			$this->db->update('kabupaten',$data);
			redirect('admin/Kabupaten');
	}

}

   
?>