<?php


class Kecamatan_model extends CI_model{

	function get_datakecamatan()
	{
		$query= $this->db->get('kecamatan');
		return $query->result_array();
	}
		function prosesAddData(){
		$id_kecamatan= $this->input->post('id_kec');
		$nama_kecamatan= $this->input->post('nama_kec');
		$id_kabupaten= $this->input->post('id_kab');
               //Mmebuat array data untuk dimasukkan ke tabel kecamatan
		$data = array(
			'id_kec' => $id_kecamatan,
			'nama_kec' => $nama_kecamatan,
			'id_kab' => $id_kabupaten,
		);

		// menimpan data ke tabel kecamatan
		$this ->db->insert('kecamatan',$data);
		$this->session->set_flashdata('notif', 'Data Kecamatan Berhasil Ditambahakan');
		redirect(base_url('admin/Kecamatan'));


	} 

	function hapusData($id_kec){
		$this->db->where('id_kec',$id_kec);
		$this->db->delete('kecamatan');
		$this->session->set_flashdata('notif', 'Data Kecamatan berhasil dihapus');
		redirect(base_url('admin/Kecamatan'));

	}
	function ProsesUpdateData(){
		$id_kecamatan= $this->input->post('id_kec');
		$nama_kecamatan= $this->input->post('nama_kec');
		$id_kabupaten= $this->input->post('id_kab');
	
			$data= array('id_kec' => $id_kecamatan ,
						'nama_kec' =>$nama_kecamatan,
						'id_kab' =>$id_kabupaten);
			$this->db->where('id_kec',$id_kecamatan);
			$this->db->update('kecamatan',$data);
			redirect('admin/Kecamatan');
	}

}

   
?>