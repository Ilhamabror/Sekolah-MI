<?php


class Mahasiswa_model extends CI_model{
	
	function get_data()
	{
		$query= $this->db->get('admin');
		return $query->result_array();
	}
	function get_dataadmin()
	{
		$query= $this->db->get('mahasiswa');
		return $query->result_array();
	}
		function prosesAddData(){
		$nim= $this->input->post('nim');
		$nama= $this->input->post('nama');
		$jk= $this->input->post('jk');
		$tmp_lahir= $this->input->post('tmp_lahir');
		$tgl_lahir= $this->input->post('tgl_lahir');
		$agama= $this->input->post('agama');
		$alamat= $this->input->post('alamat');
		$latitude= $this->input->post('latitude');
		$longtitude= $this->input->post('longtitude');
		$no_hp= $this->input->post('hp');
		$id_kel= $this->input->post('kel');
		$id_admin= $this->input->post('admin');
		$foto= $_FILES['foto'];
		if($foto=''){}
			else
			{
				$config['upload_path']          = './assets/foto';
                $config['allowed_types']        = 'gif|jpg|png|JPG|pdf';	
				$this->load->library('upload', $config);
				if ( ! $this->upload->do_upload('foto'))
                {
                        echo"gagal tambah";
                }
                else
                {

                        $foto=$this->upload->data();
                        $foto=$foto['file_name'];
						$data= array('nim' => $nim ,
									'nama' =>$nama ,
									'jenis_kelamin' =>$jk ,
									'tempat_lahir' =>$tmp_lahir ,
									'tanggal_lahir' =>$tgl_lahir ,
									'agama' =>$agama ,
									'alamat' =>$alamat ,
									'latitude' =>$latitude ,
									'longtitude' =>$longtitude ,
									'no_hp' => $no_hp ,
									'id_kel' =>$id_kel ,
									'foto' =>$foto ,
									'id_admin' =>$id_admin );
						$this->db->insert('mahasiswa',$data);
						$this->session->set_flashdata('notif','Berhasil ditambah');
						redirect(base_url('admin/mahasiswa'));
                }
			}
	} 

	function hapusData($nim){
		$this->db->where('nim',$nim);
		$this->db->delete('mahasiswa');
	}
	function ProsesUpdateData(){
		$nim= $this->input->post('nim');
		$nama= $this->input->post('nama');
		$jk= $this->input->post('jk');
		$tmp_lahir= $this->input->post('tmp_lahir');
		$tgl_lahir= $this->input->post('tgl_lahir');
		$agama= $this->input->post('agama');
		$alamat= $this->input->post('alamat');
		$latitude= $this->input->post('latitude');
		$longtitude= $this->input->post('longtitude');
		$no_hp= $this->input->post('hp');
		$id_kel= $this->input->post('kel');
		$id_admin= $this->input->post('admin');
		$fotobaru= $_FILES['foto'];
		$fotolama= $this->input->post('fotolama');
		
				$config['upload_path']          = './assets/foto/';
                $config['allowed_types']        = 'gif|jpg|png|JPG|pdf|PNG';	
				$this->load->library('upload', $config);
				if ( ! $this->upload->do_upload('foto'))
                {
            		$foto=$fotolama;
                	
                }
                else
                {

                    $fotobaru=$this->upload->data();
                    $foto=$fotobaru['file_name'];
					
				}
				
			$data= array('nim' => $nim ,
						'nama' =>$nama ,
						'jenis_kelamin' =>$jk ,
						'tempat_lahir' =>$tmp_lahir ,
						'tanggal_lahir' =>$tgl_lahir ,
						'agama' =>$agama ,
						'alamat' =>$alamat ,
						'latitude' =>$latitude ,
						'longtitude' =>$longtitude ,
						'no_hp' => $no_hp ,
						'id_kel' =>$id_kel ,
						'foto' =>$foto ,
						'id_admin' =>$id_admin );
			$this->db->where('nim',$nim);
			$this->db->update('mahasiswa',$data);
	}

}

   
?>