<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Form Tambah Data Kabupaten</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?=base_url()?>admin/Kabupaten/aksiAddData" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col">
                <div class="form-group row">
                    <label for="id_kab" class="col-sm-2 col-form-label">Id_Kabupaten</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="id_kab" name="id_kab">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="nama_kab" class="col-sm-2 col-form-label">Nama_Kabupaten</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nama_kab" name="nama_kab">
                      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
                    </div>
                  </div>                
                 </div>
              </div>
            </div>
        </div> 
      
    </form>
    </div>
  </div>
</div> 
