                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Data Kecamatan</h1>
                                    <a href="#" class="btn btn-success btn-icon-split mb-3">
                                        <span class="text" data-toggle="modal" data-target="#staticBackdrop">Tambah Data</span>
                                    </a>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Table Kecamatan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Kecamatan</th>
                                            <th>Nama Kecamatan</th>
                                            <th>ID Kabupaten</th>
                                            <th>Aksi</th>
                                           
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php foreach($kecamatan as $kec){?>
                                        <tr>
                                            <td><?= $kec['id_kec']?></td>
                                            <td><?= $kec['nama_kec']?></td>
                                             <td><?= $kec['id_kab']?></td>
                                            
                                            <td><a class="badge badge-warning" href="#/<?=$kec['id_kec']?>"><span class="text" data-toggle="modal" data-target="#editData<?=$kec['id_kec']?>">edit</span></a>
                                            <a class="badge badge-danger" href="<?= base_url()?>admin/kecamatan/hapus/<?=$kec['id_kec']?>" onclick="return confirm('Yakin Anda akan menghapus data Kecamatan : <?= $kec['id_kec']?>')">Hapus </a></td>
                                        </tr>
                                    <?php }?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
