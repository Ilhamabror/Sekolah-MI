                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Data Mahasiswa</h1>
                                    <a href="#" class="btn btn-success btn-icon-split mb-3">
                                        <span class="text" data-toggle="modal" data-target="#staticBackdrop">Tambah Data</span>
                                    </a>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTable Mahasiswa</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NIM</th>
                                            <th>Nama</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Tempat Lahir</th>
                                            <th>Tanggal Lahir</th>
                                            <th>Agama</th>
                                            <th>Alamat</th>
                                            <th>Latitude</th>
                                            <th>Longtitude</th>
                                            <th>NO HP</th>
                                            <th>ID kelurahan</th>
                                            <th>Foto</th>
                                            <th>ID Admin</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php foreach($mahasiswa as $mhs){?>
                                        <tr>
                                            <td><?= $mhs['nim']?></td>
                                            <td><?= $mhs['nama']?></td>
                                             <td><?= $mhs['jenis_kelamin']?></td>
                                            <td><?= $mhs['tempat_lahir']?></td>
                                            <td><?= $mhs['tanggal_lahir']?></td>
                                            <td><?= $mhs['agama']?></td>
                                            <td><?= $mhs['alamat']?></td>
                                            <td><?= $mhs['latitude']?></td>
                                            <td><?= $mhs['longtitude']?></td>
                                            <td><?= $mhs['no_hp']?></td>
                                            <td><?= $mhs['id_kel']?></td>
                                            <td><img src="<?= base_url()?>assets/foto/<?=$mhs['foto']?>" height="70" width="70"> </td>
                                            <td><?= $mhs['id_admin']?></td>
                                            <td><a class="badge badge-warning" href="#/<?=$mhs['nim']?>"><span class="text" data-toggle="modal" data-target="#editData<?=$mhs['nim']?>">edit</span></a>
                                            <a class="badge badge-danger" href="<?= base_url()?>admin/mahasiswa/hapus/<?=$mhs['nim']?>" onclick="return confirm('Yakin Anda akan menghapus data Nim : <?= $mhs['nim']?>')">Hapus </a></td>
                                        </tr>
                                    <?php }?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
