<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Form Tambah Data Mahasiswa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?=base_url()?>admin/mahasiswa/aksiAddData" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col">
                <div class="form-group row">
                    <label for="nim" class="col-sm-2 col-form-label">NIM</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nim" name="nim">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nama" name="nama">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="jk" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="jk" name="jk">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="tmp" class="col-sm-2 col-form-label">Tempat Lahir</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="tmp" name="tmp_lahir">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="tgl" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="tgl" name="tgl_lahir">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="agama" class="col-sm-2 col-form-label">Agama</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="agama" name="agama">
                    </div>
                  </div>
            </div>
            <div class="col">
                <div class="form-group row">
                    <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="alamat" name="alamat">
                    </div>
                  </div>
                <div class="form-group row">
                    <label for="latitude" class="col-sm-2 col-form-label">Latitude</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="latitude" name="latitude">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="longtitude" class="col-sm-2 col-form-label">Longtitude</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="longtitude" name="longtitude">
                    </div>
                  </div>
              


                <div class="form-group row">
                  <label for="hp" class="col-sm-2 col-form-label">No HP</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="hp" name="hp">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="kel" class="col-sm-2 col-form-label">Id Kelurahan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="kel" name="kel">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="foto" class="col-sm-2 col-form-label">Foto</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="foto" name="foto">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="admin" class="col-sm-2 col-form -label">Id Admin</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="admin" name="admin">
                  </div>
                </div>
              </div>
            </div>
        </div> 
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
    </div>
  </div>
</div> 
