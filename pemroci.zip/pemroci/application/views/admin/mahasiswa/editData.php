<!-- Modal -->
<?php foreach($mahasiswa as $mhs){?>
<div class="modal fade" id="editData<?=$mhs['nim']?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Form Edit Data Mahasiswa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?=base_url()?>admin/mahasiswa/aksiEditData" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col">
                <div class="form-group row">
                    <label for="nim" class="col-sm-2 col-form-label">NIM</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nim" name="nim" value="<?=$mhs['nim']?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nama" name="nama" value="<?=$mhs['nama']?>"> 
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="jk" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                    <div class="col-sm-10">
                      <select class="form-control" id="jk" name="jk">
                          <option value="<?=$mhs['jenis_kelamin']?>"><?=$mhs['jenis_kelamin']?></option>
                          <option value="Laki-laki">Laki-laki</option>
                          <option value="Perempuan">Perempuan</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="tmp" class="col-sm-2 col-form-label">Tempat Lahir</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="tmp" name="tmp_lahir" value="<?=$mhs['tempat_lahir']?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="tgl" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                    <div class="col-sm-10">
                      <input type="date" class="form-control" id="tgl" name="tgl_lahir" value="<?=$mhs['tanggal_lahir']?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="agama" class="col-sm-2 col-form-label">Agama</label>
                    <div class="col-sm-10">
                      <select class="form-control" id="agama" name="agama">
                          <option value="<?=$mhs['agama']?>">-- <?=$mhs['agama']?> --</option>
                          <option value="Islam">Islam</option>
                          <option value="Kristen">Kristen</option>
                          <option value="Hindu">Hindu</option>
                          <option value="Budha">Budha</option>
                          <option value="Lainnya">Lainnya</option>
                      </select>
                    </div>
                  </div>
            </div>
            <div class="col">
                <div class="form-group row">
                    <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="alamat" name="alamat" value="<?=$mhs['alamat']?>">
                    </div>
                  </div>
                
                <div class="form-group row">
                    <label for="latitude" class="col-sm-2 col-form-label">Latitude</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="latitude" name="latitude" value="<?=$mhs['latitude']?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="longtitude" class="col-sm-2 col-form-label">Longtitude</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="longtitude" name="longtitude" value="<?=$mhs['longtitude']?>">
                    </div>
                  </div>
                <div class="form-group row">
                  <label for="hp" class="col-sm-2 col-form-label">No HP</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="hp" name="hp" value="<?=$mhs['no_hp']?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="kelurahan">Id Kelurahan</label>
                  <div class="col-sm-10">
                    <select class="form-control" id="kelurahan" name="kel">
                      <?php foreach($kelurahan as $kel){?>
                          <option value="<?= $kel['id_kel']?>"> <?= $kel['id_kel']." | ".$kel['nama_kel']?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="foto" class="col-sm-2 col-form-label">Foto</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="foto" name="foto" value="<?=$mhs['foto']?>">
                    <input type="hidden" class="form-control" id="foto" name="fotolama" value="<?=$mhs['foto']?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="admin" class="col-sm-2 col-form-label">Id Admin</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="admin" name="admin" value="<?=$mhs['id_admin']?>">
                  </div>
                </div>
              </div>
            </div>
        </div> 
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
    </div>
  </div>
</div>
<?php }?>
