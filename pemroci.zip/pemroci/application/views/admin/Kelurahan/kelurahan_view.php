                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Data Kelurahan</h1>
                                    <a href="#" class="btn btn-success btn-icon-split mb-3">
                                        <span class="text" data-toggle="modal" data-target="#staticBackdrop">Tambah Data</span>
                                    </a>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Table Kelurahan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Kelurahan</th>
                                            <th>Nama Kelurahan</th>
                                            <th>ID Kecamatan</th>
                                            <th>Aksi</th>
                                           
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php foreach($kelurahan as $kel){?>
                                        <tr>
                                            <td><?= $kel['id_kel']?></td>
                                            <td><?= $kel['nama_kel']?></td>
                                             <td><?= $kel['id_kec']?></td>
                                            
                                            <td><a class="badge badge-warning" href="#/<?=$kel['id_kel']?>"><span class="text" data-toggle="modal" data-target="#editData<?=$kel['id_kel']?>">edit</span></a>
                                            <a class="badge badge-danger" href="<?= base_url()?>admin/kelurahan/hapus/<?=$kel['id_kel']?>" onclick="return confirm('Yakin Anda akan menghapus data Kelurahan : <?= $kel['id_kel']?>')">Hapus </a></td>
                                        </tr>
                                    <?php }?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
