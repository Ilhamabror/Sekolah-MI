<!-- Modal -->
<?php foreach($kelurahan as $kel){?>
<div class="modal fade" id="editData<?=$kel['id_kel']?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Form Edit Data Kelurahan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?=base_url()?>admin/Kelurahan/aksiEditData" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col">
                <div class="form-group row">
                    <label for="id_kel" class="col-sm-2 col-form-label">id_kelurahan</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="id_kel" name="id_kel" value="<?=$kel['id_kel']?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="nama_kel" class="col-sm-2 col-form-label">Nama_kelurahan</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nama_kel" name="nama_kel" value="<?=$kel['nama_kel']?>"> 
                    </div>
                  </div>
                   <div class="col">
                <div class="form-group row">
                    <label for="id_kec" class="col-sm-2 col-form-label">id_kecamatan</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="id_kec" name="id_kec" value="<?=$kel['id_kec']?>">
                    </div>
                  </div>
        
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
    </div>
  </div>
</div>
<?php }?>
