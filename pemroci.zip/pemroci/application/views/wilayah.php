<div class="container">
	<br>
<h2>Sistem Informasi Geografis</h2>
<hr>
<p><h4>INSTITUT TEKNOLOGI MOJOSARI</h4></p>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3954.1256061358977!2d111.88608041019454!3d-7.6696430923151615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e784db1a0d05bcd%3A0xc893a7b528652bcf!2sINSTITUT%20TEKNOLOGI%20MOJOSARI!5e0!3m2!1sid!2sid!4v1728286158379!5m2!1sid!2sid" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
