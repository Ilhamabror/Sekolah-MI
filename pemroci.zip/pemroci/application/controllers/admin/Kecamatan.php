<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kecamatan extends CI_Controller {
	public function __construct(){
		parent::__construct();
		#if ($this->session->userdata('status')!='login'){
			#redirect (base_url('login'));
		
		
        #}
        $this->load->model('Kecamatan_model');
	}
	
	
	public function index()
	{
		$data['kecamatan']=$this->Kecamatan_model->get_datakecamatan();
		$this->load->view('admin/header');
		$this->load->view('admin/side_bar');
		$this->load->view('admin/top_bar');
		$this->load->view('admin/Kecamatan/addData');
		$this->load->view('admin/Kecamatan/Kecamatan_view',$data);
		$this->load->view('admin/Kecamatan/editData',$data);
		$this->load->view('admin/footer');
	}
    public function aksiAddData(){
    	$this->Kecamatan_model->prosesAddData();
    }
	public function hapus($id_kec){
		$this->Kecamatan_model->hapusData($id_kec);
		$this->session->set_flashdata('notif','Pesan telah dihapus');
		redirect( base_url('admin/Kecamatan'));
	}
	public function aksiEditData(){
		$this->Kecamatan_model->prosesUpdatedata();
		$this->session->set_flashdata('notif','Data telah diupdate');
		redirect( base_url('admin/Kecamatan'));
	}
	
}

