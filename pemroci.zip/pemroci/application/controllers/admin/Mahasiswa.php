<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {
	public function __construct(){
		parent::__construct();
		//if ($this->session->userdata('status')!='login'){
			#redirect (base_url('login'));
		
		
        //}
        $this->load->model('Mahasiswa_model');
	}
	
	
	public function index()
	{
		$data['mahasiswa']=$this->Mahasiswa_model->get_dataadmin();
		$this->load->view('admin/header');
		$this->load->view('admin/side_bar');
		$this->load->view('admin/top_bar');
		$this->load->view('admin/mahasiswa/addData');
		$this->load->view('admin/mahasiswa/mahasiswa_view',$data);
		$this->load->view('admin/mahasiswa/editData');
		$this->load->view('admin/footer');
	}
    public function aksiAddData(){
    	$this->Mahasiswa_model->prosesAddData();
    }
	public function hapus($nim){
		$this->Mahasiswa_model->hapusData($nim);
		$this->session->set_flashdata('notif','Pesan telah dihapus');
		redirect( base_url('admin/mahasiswa'));
	}
	public function aksiEditData(){
		$this->Mahasiswa_model->prosesUpdatedata();
		$this->session->set_flashdata('notif','Data telah diupdate');
		redirect( base_url('admin/mahasiswa'));
	}
	public function mahasiswa2() 
	{
		$this->load->model('Mahasiswa_model');
		$data['mahasiswa2']=$this->Mahasiswa_model->get_dataadmin();
		$this->load->view('vmahasiswa2',$data);
	}
}

