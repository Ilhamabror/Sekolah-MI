<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kabupaten extends CI_Controller {
	public function __construct(){
		parent::__construct();
		#if ($this->session->userdata('status')!='login'){
			#redirect (base_url('login'));
		
		
        #}
        $this->load->model('Kabupaten_model');
	}
	
	
	public function index()
	{
		$data['kabupaten']=$this->Kabupaten_model->get_datakabupaten();
		$this->load->view('admin/header');
		$this->load->view('admin/side_bar');
		$this->load->view('admin/top_bar');
		$this->load->view('admin/Kabupaten/addData');
		$this->load->view('admin/Kabupaten/Kabupaten_view',$data);
		$this->load->view('admin/Kabupaten/editData',$data);
		$this->load->view('admin/footer');
	}
    public function aksiAddData(){
    	$this->Kabupaten_model->prosesAddData();
    }
	public function hapus($id_kab){
		$this->Kabupaten_model->hapusData($id_kab);
		$this->session->set_flashdata('notif','Pesan telah dihapus');
		redirect( base_url('admin/Kabupaten'));
	}
	public function aksiEditData(){
		$this->Kabupaten_model->prosesUpdatedata();
		$this->session->set_flashdata('notif','Data telah diupdate');
		redirect( base_url('admin/Kabupaten'));
	}
	
}

