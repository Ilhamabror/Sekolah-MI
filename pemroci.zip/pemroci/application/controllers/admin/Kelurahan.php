<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelurahan extends CI_Controller {
	public function __construct(){
		parent::__construct();
		#if ($this->session->userdata('status')!='login'){
			#redirect (base_url('login'));
		
		
        #}
        $this->load->model('Kelurahan_model');
	}
	
	
	public function index()
	{
		$data['kelurahan']=$this->Kelurahan_model->get_datakelurahan();
		$this->load->view('admin/header');
		$this->load->view('admin/side_bar');
		$this->load->view('admin/top_bar');
		$this->load->view('admin/Kelurahan/addData');
		$this->load->view('admin/Kelurahan/Kelurahan_view',$data);
		$this->load->view('admin/Kelurahan/editData',$data);
		$this->load->view('admin/footer');
	}
    public function aksiAddData(){
    	$this->Kelurahan_model->prosesAddData();
    }
	public function hapus($id_kel){
		$this->Kelurahan_model->hapusData($id_kel);
		$this->session->set_flashdata('notif','Pesan telah dihapus');
		redirect( base_url('admin/Kelurahan'));
	}
	public function aksiEditData(){
		$this->Kelurahan_model->prosesUpdatedata();
		$this->session->set_flashdata('notif','Data telah diupdate');
		redirect( base_url('admin/Kelurahan'));
	}
	
}

