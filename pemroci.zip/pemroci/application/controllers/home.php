<?php
class home extends CI_Controller{

	public function index(){
		$this->load->view('navbar');
		$this->load->view('content');
		$this->load->view('footer');
	}
	public function wilayah(){
		$this->load->view('navbar');
		$this->load->view('wilayah');
		$this->load->view('footer');
	
	}
	public function login(){
		$this->load->view('navbar');
		$this->load->view('login');
		$this->load->view('footer');
	}
	
	}
?>