<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {
	public function __construct(){
		parent::__construct();
		if ($this->session->userdata('status')!='login')
			{redirect (base_url('login'));}
	}
	
	public function index()
	{
		$this->load->model('Mahasiswa_model');
		$data['mahasiswa']=$this->Mahasiswa_model->get_data();
		$this->load->view('vmahasiswa',$data);
	}
	public function mahasiswa2() 
	{
		$this->load->model('Mahasiswa_model');
		$data['mahasiswa2']=$this->Mahasiswa_model->get_dataadmin();
		$this->load->view('vmahasiswa2',$data);
	}
	
	
}

